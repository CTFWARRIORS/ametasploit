clear
sleep 1.5
#exit
apt update 
apt upgrade 
apt install git -y
clear
git clone https://github.com/CTFWARRIORS/fix-metasploit.git
cd fix-metasploit
clear
bash install.sh
bash main.sh

